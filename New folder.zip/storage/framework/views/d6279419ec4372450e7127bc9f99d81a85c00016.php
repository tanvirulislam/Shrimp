<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('/')); ?>public/frontEnd/images/logo.png" type="image/x-icon" />
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,300i,400,400i,700,700i" rel="stylesheet">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>public/frontEnd/css/bootstrap.min.css" />
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/')); ?>public/frontEnd/css/font-awesome.min.css" /> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha512-SfTiTlX6kk+qitfevl/7LibUOeJWlt9rbyDn92a1DqWOw9vWG2MFoays0sgObmWazO5BQPiFucnnEAjpAB+/Sw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- <link rel="stylesheet" href="<?php echo e(asset('/')); ?>public/frontEnd/css/flaticon.css" /> -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>public/frontEnd/css/slicknav.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>public/frontEnd/css/jquery-ui.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>public/frontEnd/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>public/frontEnd/css/animate.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>public/frontEnd/css/style.css" />

    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144"
        href="<?php echo e(asset('/')); ?>public/frontEnd/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114"
        href="<?php echo e(asset('/')); ?>public/frontEnd/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72"
        href="<?php echo e(asset('/')); ?>public/frontEnd/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed"
        href="<?php echo e(asset('/')); ?>public/frontEnd/images/ico/apple-touch-icon-57-precomposed.png">
    <link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <?php echo $__env->make('frontEnd.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('body'); ?>


    <?php echo $__env->make('frontEnd.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <script src="<?php echo e(asset('/')); ?>public/frontEnd/js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>public/frontEnd/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>public/frontEnd/js/jquery.slicknav.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>public/frontEnd/js/owl.carousel.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>public/frontEnd/js/jquery.nicescroll.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>public/frontEnd/js/jquery.zoom.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>public/frontEnd/js/jquery-ui.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>public/frontEnd/js/main.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script> -->
    <script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
    <?php echo Toastr::message(); ?>

    <script>
    <?php if($errors -> any()): ?>
    <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    toastr.error('<?php echo e($error); ?>', 'Error', {
        closeButton: true,
        progressBar: true,
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </script>
    
    <script>
    $(document).ready(function() {
        $(".search_icon").click(function() {
            $(".small_screen_search").slideDown("slow");
        });
    });
    </script>
    
</body><?php /**PATH C:\xampp\htdocs\New folder\resources\views/frontEnd/master/master.blade.php ENDPATH**/ ?>