<header class="header-section">
    <div class="header-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 text-center text-lg-left">
                    <!-- logo -->
                    <a href="<?php echo e(route('index')); ?>" class="site-logo">
                        <img src="<?php echo e(asset('/')); ?><?php echo e($logo->image); ?>" alt="image">
                    </a>
                </div>
                <div class="col-xl-6 col-lg-5">
                    <form method="get" action="<?php echo e(route('search')); ?>" class="header-search-form">
                        <input name="search" type="text" placeholder="Search fish ....">
                        <button><i class="fa fa-search" aria-hidden="true"></i></button>
                    </form>
                </div>
                <div class="col-xl-4 col-lg-5">
                    <div class="user-panel">
                        <div class="up-item">
                            <i class="fa fa-user-o" aria-hidden="true"></i>
                            <?php if(Auth::check()): ?>
                            <a class="small_screen_a" href="<?php echo e(route('user_pending_order')); ?>">Sign In or Create
                                account</a>
                            <?php else: ?>
                            <a class="small_screen_a" href="<?php echo e(route('customer_dashoard_login')); ?>">Sign In or Create
                                account </a>
                            <?php endif; ?>
                        </div>
                        <div class="up-item">
                            <div class="shopping-card">
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                <span><?php echo e(Cart::getContent()->count()); ?></span>
                            </div>
                            <a href="<?php echo e(route('cart.index')); ?>">Shopping Cart</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <nav class="main-navbar">
        <!-- for small screen -->

        <a  href="<?php echo e(route('index')); ?>" class="site-logo small_screen_logo">
            <img src="<?php echo e(asset('/')); ?><?php echo e($logo->image); ?>" alt="image">
        </a>
        <div class="small_screen_cart">
            <a style="color:white" class="site-logo small_screen_icon href=" href="<?php echo e(route('cart.index')); ?>"><i class="fa fa-shopping-cart"
                    aria-hidden="true"></i>
                <sup><?php echo e(Cart::getContent()->count()); ?></sup>
            </a>
            &nbsp;
            <i class="fa fa-search search_icon" aria-hidden="true"></i>
        </div>

        <!-- for small screen -->
        <div class="container">
            <!-- menu -->
            <ul class="main-menu">
                <li><a href="<?php echo e(route('index')); ?>">Home</a></li>

                <li><a href="#">Category</a>
                    <ul class="sub-menu">
                        <?php $__currentLoopData = $nav_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('cat_wise_all_product', $categories->slug)); ?>"><?php echo e($categories->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>

                <li><a href="#">Shop</a>
                    <ul class="sub-menu">
                        <li><a href="<?php echo e(route('all_products')); ?>">All products</a></li>
                        <li><a href="<?php echo e(route('cart.index')); ?>">Cart<sup><?php echo e(Cart::getContent()->count()); ?></sup></a></li>
                        <li>
                            <?php if(Auth::check()): ?>
                            <a class="" href="#">Wishlist
                                <sup><?php echo e($wishlist); ?></sup></a>
                            <?php else: ?>
                            <a class="" href="#">Wishlist<sup><?php echo e($wishlist); ?></sup></a>
                            <?php endif; ?>
                        </li>


                    </ul>
                </li>
                <li> <?php if(Auth::check()): ?>
                    <a class="small_screen_a" href="<?php echo e(route('user_pending_order')); ?>">Sign In or Create
                        account</a>
                    <?php else: ?>
                    <a class="small_screen_a" href="<?php echo e(route('customer_dashoard_login')); ?>">Sign In or Create
                        account </a>
                    <?php endif; ?>
                </li>
                <li><a href="#">Contact</a> </li>
                <li><a href="#">Blog</a></li>
            </ul>
        </div>
    </nav>

    <div class="col-12 small_screen_search">
        <form method="get" action="<?php echo e(route('search')); ?>" class="header-search-form">
            <input name="search" type="text" placeholder="Search fish ....">
            <button><i style="color: #2c976b;" class="fa fa-search" aria-hidden="true"></i></button>
        </form>
    </div>
</header><?php /**PATH C:\xampp\htdocs\New folder\resources\views/frontEnd/layout/header.blade.php ENDPATH**/ ?>