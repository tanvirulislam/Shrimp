
<?php $__env->startSection('title'); ?>
DESH BANGLA FISH & SHRIMP
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>


<!-- Hero section -->
<section class="hero-section">
    <div class="hero-slider owl-carousel">
        <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="hs-item set-bg" data-setbg="<?php echo e($ban->image); ?>">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-7 text-white">
                        <span class="banner_font"><?php echo e($ban->product_name); ?></span>
                        <h2 class="banner_font"><?php echo e($ban->title); ?></h2>
                        <p class="banner_font"><?php echo e($ban->desp); ?> </p>
                        <a href="#" class="site-btn sb-line">DISCOVER</a>
                        <a href="#" class="site-btn sb-white">ADD TO CART</a>
                    </div>
                </div>
                <div class="offer-card text-white">
                    <span>from</span>
                    <h3>TK 150</h3>
                    <p>SHOP NOW</p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="container">
        <div class="slide-num-holder" id="snh-1"></div>
    </div>
</section>
<!-- Hero section end -->



<!-- Features section -->

<!-- <section class="features-section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 p-0 feature">
                <div class="feature-inner">
                    <div class="feature-icon">
                        <img src="img/icons/1.png" alt="#">
                    </div>
                    <h2>Fast Secure Payments</h2>
                </div>
            </div>
            <div class="col-md-4 p-0 feature">
                <div class="feature-inner">
                    <div class="feature-icon">
                        <img src="img/icons/2.png" alt="#">
                    </div>
                    <h2>Premium Products</h2>
                </div>
            </div>
            <div class="col-md-4 p-0 feature">
                <div class="feature-inner">
                    <div class="feature-icon">
                        <img src="img/icons/3.png" alt="#">
                    </div>
                    <h2>Free & fast Delivery</h2>
                </div>
            </div>
        </div>
    </div>
</section> -->

<!-- Features section end -->


<!-- letest product section -->
<section class="top-letest-product-section">
    <div class="container">
        <div class="section-title">
            <h2>Feature Product</h2>
        </div>
        <div class="product-slider owl-carousel">
            <?php $__currentLoopData = $feature_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="product-item">
                <div class="pi-pic">
                    <img src="<?php echo e(asset('/')); ?><?php echo e($item->image); ?>" alt="image">
                    <div class="pi-links">

                        <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" value="<?php echo e($item->product_slug); ?>" id="id" name="id">
                            <input type="hidden" value="<?php echo e($item->name); ?>" id="name" name="name">
                            <input type="hidden" value="<?php echo e($item->sell_price); ?>" id="price" name="price">
                            <input type="hidden" value="<?php echo e($item->image); ?>" id="img" name="img">

                            <input type="hidden" id="quantity" name="quantity"
                                class="quantity form-control input-number" value="1" min="1" max="100">

                           <button type="submit" class="add-card"><i class="fa fa-shopping-cart"></i>
                                <span >ADD TO CART</span></button>

                            <a href="#" class="wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                        </form>

                        <!-- <a href="#" class="add-card"> <i class="fa fa-shopping-cart" aria-hidden="true"></i><span>ADD TO
                                CART</span></a> -->

                    </div>
                </div>
                <div class="pi-text">
                    <div class="row">
                        <div class="col-md-5 col-5" >
                            <h6><?php echo e($item->name); ?> </h6>

                        </div>
                        <div class="col-md-7 col-5">
                            <span><?php echo e($item->sell_price); ?> TK</span> &nbsp;
                            <span style="float: right"><?php echo e($item->weight); ?> KG</span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- letest product section end -->



<!-- Product filter section -->
<section class="product-filter-section">
    <div class="container">
        <div class="section-title">
            <h2>LATEST PRODUCTS</h2>
        </div>
        <ul class="product-filter-menu">
            <?php $__currentLoopData = $category_fish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('cat_wise_all_product', $item->slug)); ?>"><?php echo e($item->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="row">
            <?php $__currentLoopData = $feature_item->shuffle()->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-sm-6">
                <div class="product-item">
                    <div class="pi-pic">
                        <img src="<?php echo e(asset('/')); ?><?php echo e($item->image); ?>" alt="image">
                        <div class="pi-links">
                            <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" value="<?php echo e($item->product_slug); ?>" id="id" name="id">
                                <input type="hidden" value="<?php echo e($item->name); ?>" id="name" name="name">
                                <input type="hidden" value="<?php echo e($item->sell_price); ?>" id="price" name="price">
                                <input type="hidden" value="<?php echo e($item->image); ?>" id="img" name="img">

                                <input type="hidden" id="quantity" name="quantity"
                                    class="quantity form-control input-number" value="1" min="1" max="100">

                                <button type="submit" class="add-card"><i class="fa fa-shopping-cart"></i>
                                <span >ADD TO CART</span></button>
                                <a href="#" class="wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                            </form>

                        </div>
                    </div>
                    <div class="pi-text">
                        <div class="row">
                            <div class="col-md-5">
                                <h6><?php echo e($item->name); ?> </h6>

                            </div>
                            <div class="col-md-7">
                                <span><?php echo e($item->sell_price); ?> TK</span> &nbsp;
                                <span style="float: right"><?php echo e($item->weight); ?> KG</span>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="text-center">
            <a href="<?php echo e(route('all_products')); ?>" class="site-btn sb-line sb-dark">LOAD MORE</a>
        </div>
    </div>
</section>
<!-- Product filter section end -->


<!-- Banner section -->
<section class="banner-section">
    <div class="container">
        <div class="banner set-bg" data-setbg="<?php echo e(asset('/')); ?><?php echo e($offer->image); ?>">
            <div class="tag-new">15% OFF</div>
            <span style="color:white">Stock Available</span>
            <h2 style="color:white">Deshi Fish</h2>
            <a href="#" class="site-btn">SHOP NOW</a>
        </div>
    </div>
</section>
<!-- Banner section end  -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\New folder\resources\views/frontEnd/index.blade.php ENDPATH**/ ?>