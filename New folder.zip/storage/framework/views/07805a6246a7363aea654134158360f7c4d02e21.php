
<?php $__env->startSection('title'); ?>
Search Item | Fish & Shrimp E-commerce
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<br>
<div class="container">
    <?php if($product->isNotEmpty()): ?>
    <div class="row">
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-9  order-2 order-lg-2 mb-5 mb-lg-0">
            <div class="row">

                <div class="col-lg-4 col-sm-6">
                    <a class="gg" style="background:transparent"
                        href="<?php echo e(route('product_details', $cat_product->product_slug)); ?>">

                        <div class="product-item">
                            <div class="pi-pic">
                                <div class="tag-sale">ON SALE</div>
                                <img src="<?php echo e(asset('/')); ?><?php echo e($cat_product->image); ?>" alt="image">
                                <div class="pi-links">
                                    <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" value="<?php echo e($cat_product->product_slug); ?>" id="id" name="id">
                                        <input type="hidden" value="<?php echo e($cat_product->name); ?>" id="name" name="name">
                                        <input type="hidden" value="<?php echo e($cat_product->sell_price); ?>" id="price"
                                            name="price">
                                        <input type="hidden" value="<?php echo e($cat_product->image); ?>" id="img" name="img">

                                        <input type="hidden" id="quantity" name="quantity"
                                            class="quantity form-control input-number" value="1" min="1" max="100">
                                       


                                        <a href="#" style="    margin-left: 11px;" class="wishlist-btn"><i
                                                class="fa fa-heart" aria-hidden="true"></i></a>
                                                
                                                <button type="submit" class="add-card"><i class="fa fa-shopping-cart"></i>
                                <span >ADD TO CART</span></button>
                                
                                    </form>
                                </div>
                            </div>
                            <div class="pi-text">
                                <div class="row">
                                    <div class="col-md-5">
                                        <h6><?php echo e($cat_product->name); ?> </h6>

                                    </div>
                                    <div class="col-md-7">
                                        <span><?php echo e($cat_product->sell_price); ?> TK</span> &nbsp;
                                        <span style="float: right"><?php echo e($cat_product->weight); ?> KG</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>


                <div class=" w-100 pt-3 mb-5">

                </div>


            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
    <div>
        <p>No item found</p>
    </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codetree/public_html/banglafishshrimp.com/resources/views/frontEnd/search.blade.php ENDPATH**/ ?>