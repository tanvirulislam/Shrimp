<?php $__env->startSection('title'); ?>
Products | Fish & Shrimp E-commerce
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<br><br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header"></div>
                <div class="card-body">
                    <a href="<?php echo e(route('user_pending_order')); ?>" type="button" class="btn btn-success">Pending
                        order</a>
                    <a href="<?php echo e(route('order_history')); ?>" type="button" class="btn btn-info">Order history</a>

                    <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();"><i class="material-icons"></i>Sign Out</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
                <br>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><?php echo e(__('You have successfully logged in !!!')); ?></div>

                <div class="card-body">

                </div>
            </div>
        </div>
    </div>
</div>
<br><br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codetree/public_html/banglafishshrimp.com/resources/views/home.blade.php ENDPATH**/ ?>