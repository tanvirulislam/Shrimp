
<?php $__env->startSection('title'); ?>
DESH BANGLA FISH & SHRIMP
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<!-- Page info -->
<div class="page-top-info">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h4>Your cart</h4>
                <div class="site-pagination">
                    <a href="<?php echo e(route('index')); ?>">Home</a> /
                    <a href="">Your cart</a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel-heading">
                    <?php if(\Cart::getTotalQuantity()>0): ?>
                    <h4 class="text-center" style="color:#2C976B"><b><?php echo e(Cart::getContent()->count()); ?> Item`s In Your
                            Cart<b>
                    </h4><br>
                    <?php else: ?>
                    <h4>No Item(s) In Your Cart</h4><br>
                    <a href="<?php echo e(route('index')); ?>" class="btn btn-info">Continue Shopping</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>



    </div>
</div>
<!-- Page info end -->


<!-- cart section end -->
<section class="cart-section spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="cart-table">
                    <h3>Your Cart</h3>
                    <div class="cart-table-warp">
                        <table>
                            <thead>
                                <tr>
                                    <th class="product-th">Product</th>
                                    <th class="quy-th">Weight (KG)</th>
                                    <th class="quy-th"> Subtotal (TK)</th>
                                    <th class="size-th">Action</th>
                                    <!-- <th class="total-th">Action</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cartCollection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="product-col">
                                        <img src="<?php echo e($item->attributes->image); ?>" class="img-thumbnail" alt="image"
                                            width="200" height="200">
                                        <div class="pc-title">
                                            <h4><?php echo e($item->name); ?></h4>
                                            <p><?php echo e($item->price); ?></p>
                                        </div>
                                    </td>
                                    <td class="quy-col">
                                        <div class="quantity">
                                            <!-- <div class="pro-qty"> -->
                                            <form action="<?php echo e(route('cart.update')); ?>" method="POST" class="form-inline">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group">
                                                    <input type="hidden" value="<?php echo e($item->id); ?>" id="id" name="id">
                                                    <input type="number" class="form-control form-control-sm"
                                                        value="<?php echo e($item->quantity); ?>" id="quantity" name="quantity"
                                                        style="width:70px;">
                                                </div>
                                                &nbsp;
                                                <button style="margin-top: inherit;"
                                                    class="btn btn-primary ">Update</button>
                                            </form>
                                            <!-- </div> -->
                                        </div>
                                    </td>
                                    <td class="size-col">
                                        <h4><?php echo e(\Cart::get($item->id)->getPriceSum()); ?></h4>
                                    </td>
                                    <td class="total-col">
                                        <form action="<?php echo e(route('cart.remove')); ?>" method="POST" class="form-inline">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($item->id); ?>" id="id" name="id">
                                            <button style="margin-top: inherit;" class="btn btn-primary py-2 px-3"
                                                style="">Delete</i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="total-cost">
                        <h6>Total <span>BDT. <?php echo e(\Cart::getTotal()); ?></span></h6>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 card-right">
                <form class="promo-code-form">
                    <input type="text" placeholder="Enter promo code">
                    <button>Submit</button>
                </form>
                <!-- <a href="" class="site-btn">Proceed to checkout</a>
                <a href="" class="site-btn sb-dark">Continue shopping</a> -->
                <?php if(count($cartCollection)>0): ?>
                <a href="<?php echo e(route('index')); ?>" style="margin-top: inherit;" class="site-btn">Continue
                    Shopping</a>

                <?php if(Auth::check() && Auth::user()->role_id == 2 || Session::get('customerId')): ?>
                <a href="<?php echo e(route('shipping_info')); ?>" class="site-btn">Proceed To Checkout</a>
                <?php else: ?>
                <a href="<?php echo e(route('loginPage')); ?>" class="site-btn">Proceed To Checkout</a>

                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<!-- cart section end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codetree/public_html/banglafishshrimp.com/resources/views/frontEnd/cart.blade.php ENDPATH**/ ?>